jQuery(document).ready(function(){

    jQuery('.gallery').magnificPopup({
        type: 'image',
        gallery: {
            enabled: true
        }
    });
    
    jQuery(".popup-youtube").magnificPopup({
        type: 'iframe'
    });    
    
  jQuery(".msg_body").hide();
  jQuery(".msg_head").click(function() {
    jQuery(this).next(".msg_body").slideToggle(400);
	return false;
  });
  
 /* archive */
  jQuery(".msg_hd").click(function() {
    jQuery(this).next(".msg_mn").slideToggle(400);
	return false;
  });

// scrool to top
jQuery('a.top').click(function(){
     jQuery('html, body').animate({scrollTop: '0px'}, 1000);
     return false;
});

// make all li elements in the side bar clickable!
jQuery('.panel-list li').click(function(){
	  window.location=jQuery(this).find("a").attr('href'); 
	  return false;
});

// animating shits

jQuery('#shock').hide();
	jQuery(document).ready(function () {
		jQuery('#shock').fadeIn(5000);
		return false;
});

// inspire yourself msg near logo
	jQuery(".luv a").hover(function() {
		jQuery(this).next("em").animate({opacity: "show", top: "50", left: "190"}, "6000");
	}, function() {
		jQuery(this).next("em").animate({opacity: "hide", top: "-85", left: "190"}, "4000");
		return false;
	});

// Show-Hide when scrooling!
jQuery('#up2top').hide();
jQuery(document).ready(function(){
 jQuery(window).scroll(function(){
  // get the height of #wrap
  var h = jQuery('.container').height();
  var y = jQuery(window).scrollTop();
  if( y > (h*.15) && y < (h*.99) ){
   // if we are show keyboardTips
   jQuery("#up2top").fadeIn("slow");
  } else {
   jQuery('#up2top').fadeOut('slow');
  }
 });
})


// FLASHER 
jQuery(document).ready(function () {
		jQuery("#flasher").fadeOut(100).fadeIn(100).fadeOut(100).fadeIn(100).fadeOut(100).fadeIn(100).fadeOut(300);
		return false;
});


});
